import { useState } from "react";
import "./App.css";

function App() {
  const [opcion, setOpcion] = useState("perfil");
  const [mensaje, setMensaje] = useState("");
  const [cita, setCita] = useState({
    paciente: "", telefono: "", fecha: "", servicio: "", motivo: ""
  });
  const [solicitud, setSolicitud] = useState({
    tipo: "", descripcion: "", usuario: "", contacto: "", prioridad: ""
  });

  function cambiarOpcion(nombre) {
    setOpcion(nombre);
    setMensaje("");
  }

  function generarCita(e) {
    e.preventDefault();
    setMensaje("Cita creada correctamente. Código: CITA-001. Se notificará al paciente.");
  }

  function generarSolicitud(e) {
    e.preventDefault();
    setMensaje("Solicitud registrada correctamente. Número: SOL-001.");
  }

  function emergencia() {
    setMensaje("Emergencia enviada. El equipo de atención fue notificado.");
  }

  function planAccion(accion) {
    setMensaje(`Solicitud de ${accion} registrada correctamente.`);
  }

  const menu = [
    ["perfil", "◉", "Perfil de usuario"],
    ["reportes", "▣", "Generar reportes"],
    ["citas", "▦", "Programar citas"],
    ["emergencias", "!", "Atender emergencias"],
    ["inicio", "↪", "Inicio de sesión"],
    ["solicitudes", "✉", "Solicitudes de usuario"],
    ["planes", "✓", "Planes de tratamiento"],
  ];

  return (
    <main className="pagina">
      <aside className="menu">
        <header className="marca">
          <section className="logo">RV</section>
          <section>
            <h1>RenovaVida</h1>
            <p>Gestión de salud</p>
          </section>
        </header>

        <section className="entidad">
          <span className="estado"></span>
          <section>
            <strong>Entidad de Salud</strong>
            <small>Panel administrativo</small>
          </section>
        </section>

        <nav className="navegacion" aria-label="Menú principal">
          <p className="titulo-menu">MENÚ PRINCIPAL</p>
          {menu.map(([id, icono, texto]) => (
            <button
              key={id}
              className={opcion === id ? "menu-activo" : ""}
              onClick={() => cambiarOpcion(id)}
            >
              <span className="icono">{icono}</span>
              {texto}
            </button>
          ))}
        </nav>

        <footer className="menu-footer">
          <button className="cerrar" onClick={() => setMensaje("Sesión cerrada correctamente.")}>
            ↩ Cerrar sesión
          </button>
        </footer>
      </aside>

      <section className="contenido">
        <header className="barra-superior">
          <section>
            <span className="ruta">RenovaVida / Entidades de Salud</span>
            <h2>
              {opcion === "perfil" && "Perfil de usuario"}
              {opcion === "reportes" && "Generar reportes"}
              {opcion === "citas" && "Programar citas"}
              {opcion === "emergencias" && "Atender emergencias"}
              {opcion === "inicio" && "Inicio de sesión"}
              {opcion === "solicitudes" && "Solicitudes de usuario"}
              {opcion === "planes" && "Planes de tratamiento"}
            </h2>
          </section>
          <section className="usuario">
            <span className="avatar">ES</span>
            <section>
              <strong>Entidad Salud</strong>
              <small>Administrador</small>
            </section>
          </section>
        </header>

        {opcion === "perfil" && (
          <>
            <section className="bienvenida">
              <section>
                <span className="etiqueta">PANEL DE SALUD</span>
                <h3>Bienvenido a RenovaVida</h3>
                <p>Administra información, citas, solicitudes y planes de atención desde un solo lugar.</p>
              </section>
              <section className="bienvenida-icono">♥</section>
            </section>

            <section className="estadisticas">
              <article className="tarjeta">
                <span className="tarjeta-icono azul">◉</span>
                <section><small>Usuarios activos</small><strong>128</strong><em>+12% este mes</em></section>
              </article>
              <article className="tarjeta">
                <span className="tarjeta-icono verde">▦</span>
                <section><small>Citas programadas</small><strong>24</strong><em>8 para hoy</em></section>
              </article>
              <article className="tarjeta">
                <span className="tarjeta-icono naranja">!</span>
                <section><small>Solicitudes pendientes</small><strong>07</strong><em>Requieren atención</em></section>
              </article>
            </section>

            <section className="panel-grid">
              <article className="panel">
                <header className="panel-header"><section><span className="mini-etiqueta">ENTRADA</span><h3>Consultar perfil</h3></section><span>◉</span></header>
                <p>Consulta los datos de afiliación y estado del usuario.</p>
                <label>Identificador del usuario</label>
                <input type="text" placeholder="ID o número de afiliación" />
                <button className="accion" onClick={() => setMensaje("Perfil encontrado correctamente.")}>Consultar perfil</button>
              </article>

              <article className="panel perfil-card">
                <header className="panel-header"><section><span className="mini-etiqueta">SALIDA</span><h3>Información encontrada</h3></section><span>✓</span></header>
                <section className="datos">
                  <p><span>EPS</span><strong>Nueva EPS</strong></p>
                  <p><span>Estado</span><strong className="activo">Activo</strong></p>
                  <p><span>Régimen</span><strong>Subsidiado</strong></p>
                  <p><span>Afiliación</span><strong>10/02/2026</strong></p>
                  <p><span>Contacto</span><strong>contacto@eps.com</strong></p>
                </section>
              </article>
            </section>
          </>
        )}

        {opcion === "reportes" && (
          <section className="panel grande">
            <span className="mini-etiqueta">GESTIÓN DE INFORMACIÓN</span>
            <h3>Generar reportes</h3>
            <p>Seleccione el reporte que necesita consultar o descargar.</p>
            <section className="opciones-reporte">
              {["Reporte clínico", "Reporte de alertas", "Reporte de asistencia", "Tratamientos y adherencia", "Reporte estadístico"].map((r) => (
                <button key={r} className="reporte-opcion" onClick={() => setMensaje(`${r} seleccionado.`)}>
                  <span>▣</span>{r}<b>›</b>
                </button>
              ))}
            </section>
            <button className="accion" onClick={() => setMensaje("Reporte generado correctamente.")}>Generar reporte</button>
            <button className="accion secundario" onClick={() => setMensaje("Reporte preparado para descargar en PDF o Excel.")}>Descargar</button>
            {mensaje && <section className="resultado">{mensaje}</section>}
          </section>
        )}

        {opcion === "citas" && (
          <section className="panel grande">
            <span className="mini-etiqueta">PROGRAMACIÓN</span>
            <h3>Programar cita o sesión</h3>
            <p>Complete la información para registrar una nueva atención.</p>
            <form className="formulario" onSubmit={generarCita}>
              <label>ID del paciente<input value={cita.paciente} onChange={e => setCita({...cita, paciente:e.target.value})} placeholder="Ej. PAC-001" required /></label>
              <label>Teléfono o correo<input value={cita.telefono} onChange={e => setCita({...cita, telefono:e.target.value})} placeholder="Contacto" required /></label>
              <label>Fecha y hora<input type="datetime-local" value={cita.fecha} onChange={e => setCita({...cita, fecha:e.target.value})} required /></label>
              <label>Servicio<select value={cita.servicio} onChange={e => setCita({...cita, servicio:e.target.value})} required><option value="">Seleccione</option><option>Psicología</option><option>Medicina</option><option>Trabajo social</option></select></label>
              <label className="campo-completo">Motivo<textarea value={cita.motivo} onChange={e => setCita({...cita, motivo:e.target.value})} placeholder="Escriba el motivo de la atención"></textarea></label>
              <button className="accion" type="submit">Confirmar cita</button>
            </form>
            {mensaje && <section className="resultado">{mensaje}</section>}
          </section>
        )}

        {opcion === "emergencias" && (
          <section className="emergencia-panel">
            <section className="alerta-icono">!</section>
            <span className="mini-etiqueta rojo">ATENCIÓN PRIORITARIA</span>
            <h3>Atender emergencia</h3>
            <p>Use esta opción para enviar una alerta a la entidad y comenzar el proceso de atención.</p>
            <button className="emergencia" onClick={emergencia}>ACTIVAR EMERGENCIA</button>
            {mensaje && <section className="resultado claro">{mensaje}<small> Estado: recibida y en proceso de atención.</small></section>}
          </section>
        )}

        {opcion === "inicio" && (
          <section className="login-panel">
            <section className="login-marca"><span>RV</span><h3>RenovaVida</h3><p>Acceso para entidades de salud</p></section>
            <form onSubmit={e => {e.preventDefault(); setMensaje("Inicio de sesión correcto. Bienvenido a RenovaVida.");}}>
              <label>Correo, documento o afiliación<input placeholder="Ingrese su identificador" required /></label>
              <label>Contraseña<input type="password" placeholder="Ingrese su contraseña" required /></label>
              <button className="accion" type="submit">Iniciar sesión</button>
            </form>
            {mensaje && <section className="resultado">{mensaje}</section>}
          </section>
        )}

        {opcion === "solicitudes" && (
          <section className="panel grande">
            <span className="mini-etiqueta">ATENCIÓN AL USUARIO</span>
            <h3>Atender solicitud</h3>
            <p>Registre y clasifique el requerimiento recibido.</p>
            <form className="formulario" onSubmit={generarSolicitud}>
              <label>Tipo de solicitud<select value={solicitud.tipo} onChange={e=>setSolicitud({...solicitud,tipo:e.target.value})} required><option value="">Seleccione</option><option>Información</option><option>Soporte</option><option>Documentos</option><option>Agendamiento</option><option>Queja</option></select></label>
              <label>Prioridad<select value={solicitud.prioridad} onChange={e=>setSolicitud({...solicitud,prioridad:e.target.value})}><option value="">Seleccione</option><option>Alta</option><option>Media</option><option>Baja</option></select></label>
              <label>Usuario<input value={solicitud.usuario} onChange={e=>setSolicitud({...solicitud,usuario:e.target.value})} placeholder="ID o nombre" required /></label>
              <label>Contacto<input value={solicitud.contacto} onChange={e=>setSolicitud({...solicitud,contacto:e.target.value})} placeholder="Teléfono o correo" required /></label>
              <label className="campo-completo">Descripción<textarea value={solicitud.descripcion} onChange={e=>setSolicitud({...solicitud,descripcion:e.target.value})} placeholder="Describa la solicitud" required></textarea></label>
              <button className="accion" type="submit">Registrar solicitud</button>
            </form>
            {mensaje && <section className="resultado">{mensaje}</section>}
          </section>
        )}

        {opcion === "planes" && (
          <section className="panel grande">
            <span className="mini-etiqueta">SEGUIMIENTO</span>
            <h3>Gestión de plan de tratamiento</h3>
            <p>Consulte el avance y gestione las acciones disponibles.</p>
            <article className="plan">
              <header><section><span className="avatar paciente">ER</span><section><h4>Elena Rodríguez</h4><small>Plan de tratamiento · Activo</small></section></section><strong>45%</strong></header>
              <section className="barra"><span></span></section>
              <p>Avance del plan de atención</p>
              <section className="acciones-plan">
                <button onClick={() => planAccion("modificación")}>Modificar</button>
                <button onClick={() => planAccion("suspensión")}>Suspender</button>
                <button onClick={() => planAccion("finalización")}>Finalizar</button>
                <button onClick={() => planAccion("reemplazo")}>Reemplazar</button>
              </section>
            </article>
            {mensaje && <section className="resultado">{mensaje}</section>}
          </section>
        )}

        <footer className="pie">RenovaVida · Plataforma de gestión para entidades de salud · 2026</footer>
      </section>
    </main>
  );
}

export default App;
